package com.examenB.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examenB.model.Drone;
import com.examenB.model.Instrumento;
import com.examenB.repository.DroneRepository;
import com.examenB.repository.InstrumentoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class InstrumentoServiceImp implements InstrumentoService{

	@Autowired
	InstrumentoRepository instrumentoRepo;
	@Autowired
	DroneRepository droneRepo;
	
	@Override
	public Instrumento agregarInstrumento(Long droneId, Instrumento instrumento) {
			System.out.println(instrumento);
			instrumento.setDrones(droneRepo.findById(droneId).orElse(null));
			instrumentoRepo.save(instrumento);
		return instrumento;
	}

	@Override
	public List<Instrumento> habilitadosBajoConsumo(Double maxConsumo) {
		// TODO Auto-generated method stub
		return instrumentoRepo.findByConsumoEnergiaLessThan(maxConsumo);
	}

	@Override
	public List<Instrumento> habilitadosOrdenadosPorConsumo() {
		List<Instrumento> lista = instrumentoRepo.findAll();
		for (Instrumento intrumento : lista) {
			if(intrumento.getHabilititado() == true) {
				lista.add(intrumento);
			}
		}
		return lista;
	}

	@Override
	public List<Instrumento> tipoCamaraConAlcance(Double alcanceMin) {
		List<Instrumento> ins1 = new ArrayList<>();
		for (Instrumento instrumento : instrumentoRepo.findByAlcanceMaxGreaterThan(alcanceMin)) {
			if(instrumento.getTipo().contains("camara")) {
				ins1.add(instrumento);
			}
		}
		return ins1;
	}

}

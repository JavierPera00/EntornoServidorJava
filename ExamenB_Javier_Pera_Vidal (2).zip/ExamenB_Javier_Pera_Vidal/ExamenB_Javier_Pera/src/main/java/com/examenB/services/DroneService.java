package com.examenB.services;

import java.util.List;

import com.examenB.model.Drone;

public interface DroneService {
	
	Drone crearDrone(Drone d);

	List<Drone> listarDrones();

	Drone buscarPorId(Long id);

	void eliminarDrone(Long id);

	Drone actualizarDrone(Drone d);

	List<Drone> buscarPorMision(String mision);

	List<Drone> buscarPorAnioFabricacion(Integer start, Integer end);

	long contarNoActivos();

	List<Drone> obtenerConAutonomiaCritica(Double minAutonomia);

	List<Drone> buscarPorModeloOMision(String cadena);

	boolean existePorModelo(String modelo);

	Drone obtenerDroneMasReciente();

}

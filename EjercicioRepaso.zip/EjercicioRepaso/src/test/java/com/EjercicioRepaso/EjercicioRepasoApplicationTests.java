package com.EjercicioRepaso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioRepasoApplicationTests {

	@Test
	void contextLoads() {
	}

}

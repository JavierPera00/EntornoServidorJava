package com.examenB.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examenB.model.Drone;
import com.examenB.repository.DroneRepository;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class DronServiceImp implements DroneService{

	@Autowired
	DroneRepository droneRepo;

	@Override
	public Drone crearDrone(Drone d) {
		// TODO Auto-generated method stub
		return droneRepo.save(d);
	}
	@Override
	public List<Drone> listarDrones() {
		// TODO Auto-generated method stub
		return droneRepo.findAll();
	}
	@Override
	public Drone buscarPorId(Long id) {
		// TODO Auto-generated method stub
		return droneRepo.findById(id).orElse(null);
	}
	@Override
	public void eliminarDrone(Long id) {
		// TODO Auto-generated method stub
		droneRepo.deleteById(id);
	}
	@Override
	public Drone actualizarDrone(Drone d) {
		// TODO Auto-generated method stub
		return droneRepo.save(d);
	}
	
	/*------------------------------------------*/
	@Override
	public List<Drone> buscarPorMision(String mision) {
		return droneRepo.findByMision(mision);
		
	}
	
	@Override
	public List<Drone> buscarPorAnioFabricacion(Integer start, Integer end) {
		// TODO Auto-generated method stub
		return droneRepo.findByAñoFabricacionBetween(start,end);
	}
	
	@Override
	public long contarNoActivos() {
		Boolean t = false;
		return droneRepo.countByActivo(t);
	}
	
	@Override
	public List<Drone> obtenerConAutonomiaCritica(Double minAutonomia) {
		return droneRepo.findByAutonomiaMinLessThan(minAutonomia);
	}
	
	@Override
	public List<Drone> buscarPorModeloOMision(String cadena) {
		List<Drone> lista = droneRepo.findByMisionContainingIgnoreCase(cadena);
		List<Drone> lista1 = new ArrayList<>();
		for (Drone drone : lista) {
			if(drone.getModelo().equalsIgnoreCase(cadena)) {
				lista1.add(drone);
			}
		}
		return lista1;
	}

	@Override
	public boolean existePorModelo(String modelo) {
		List<Drone> listaDrones = droneRepo.findAll();
		for (Drone drone : listaDrones) {
			if(drone.getModelo().equalsIgnoreCase(modelo)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public Drone obtenerDroneMasReciente() {
		List<Drone> listaDrones = droneRepo.findAll();
		Drone hoy = new Drone();
		hoy.setAñoFabricacion(null);
		
		for (Drone drone : listaDrones) {
			if(hoy.getAñoFabricacion() == null || drone.getAñoFabricacion() > hoy.getAñoFabricacion()) {
				hoy = drone;
			}
		}
		return hoy;
	}

	
}

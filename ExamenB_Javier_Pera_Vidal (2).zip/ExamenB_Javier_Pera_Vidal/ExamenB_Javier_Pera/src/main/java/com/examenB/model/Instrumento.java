package com.examenB.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name="instrumento")
public class Instrumento {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	@Column
	private String tipo;
	@Column
	private Double resolucion;
	@Column
	private Double alcanceMax;
	@Column
	private String unidadMedida;
	@Column
	private Boolean habilititado;
	@Column 
	private Double consumoEnergia;
	@ManyToOne
	@JoinColumn(name = "id_drone")
	private Drone drones;
	
	
	public Instrumento() {
		super();
	}
	
	public Instrumento(String tipo, Double resolucion, Double alcanceMax, String unidadMedida, Boolean habilititado,
			Double consumoEnergia, Drone drones) {
		super();
		this.tipo = tipo;
		this.resolucion = resolucion;
		this.alcanceMax = alcanceMax;
		this.unidadMedida = unidadMedida;
		this.habilititado = habilititado;
		this.consumoEnergia = consumoEnergia;
		this.drones = drones;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public Double getResolucion() {
		return resolucion;
	}
	public void setResolucion(Double resolucion) {
		this.resolucion = resolucion;
	}
	public Double getAlcanceMax() {
		return alcanceMax;
	}
	public void setAlcanceMax(Double alcanceMax) {
		this.alcanceMax = alcanceMax;
	}
	public String getUnidadMedida() {
		return unidadMedida;
	}
	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}
	public Boolean getHabilititado() {
		return habilititado;
	}
	public void setHabilititado(Boolean habilititado) {
		this.habilititado = habilititado;
	}
	public Double getConsumoEnergia() {
		return consumoEnergia;
	}
	public void setConsumoEnergia(Double consumoEnergia) {
		this.consumoEnergia = consumoEnergia;
	}
	public Drone getDrones() {
		return drones;
	}
	public void setDrones(Drone drones) {
		this.drones = drones;
	}
	@Override
	public String toString() {
		return "Instrumento [id=" + id + ", tipo=" + tipo + ", resolucion=" + resolucion + ", alcanceMax=" + alcanceMax
				+ ", unidadMedida=" + unidadMedida + ", habilititado=" + habilititado + ", consumoEnergia="
				+ consumoEnergia + "]";
	}
}

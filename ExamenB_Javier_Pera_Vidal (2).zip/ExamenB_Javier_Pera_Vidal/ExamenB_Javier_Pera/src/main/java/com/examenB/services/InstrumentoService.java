package com.examenB.services;

import java.util.List;

import com.examenB.model.Instrumento;

public interface InstrumentoService {

	Instrumento agregarInstrumento(Long droneId, Instrumento instrumento);

	List<Instrumento> habilitadosBajoConsumo(Double maxConsumo);

	List<Instrumento> habilitadosOrdenadosPorConsumo();

	List<Instrumento> tipoCamaraConAlcance(Double alcanceMin);

}
package com.examenB;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.examenB.model.Drone;
import com.examenB.model.Instrumento;
import com.examenB.services.DronServiceImp;
import com.examenB.services.DroneService;
import com.examenB.services.InstrumentoService;


@SpringBootApplication
public class ExamenBApplication implements CommandLineRunner {


	public static void main(String[] args) {
		SpringApplication.run(ExamenBApplication.class, args);
	}

	@Autowired
	DroneService dronService;
	@Autowired
	InstrumentoService instrumentoService;
	
	@Override
	public void run(String... args) throws Exception {
		
		//1
		Drone dron1 = new Drone();
		dron1.setModelo("Aero-900");
		dron1.setMision("industria");
		dron1.setAñoFabricacion(2021);
		dron1.setAutonomiaMin(95.0);
		dron1.setActivo(true);
		dron1.setPesoKg(18.0);
		dronService.crearDrone(dron1);
		//2
		Drone dron2 = new Drone();
		dron2.setModelo("Scout-X");
		dron2.setMision("reconocimiento");
		dron2.setAñoFabricacion(2017);
		dron2.setAutonomiaMin(30.0);
		dron2.setActivo(true);
		dron2.setPesoKg(6.5);
		dronService.crearDrone(dron2);
		//3
		Drone dron3= new Drone();
		dron3.setModelo("Rescue-Pro");
		dron3.setMision("rescate");
		dron3.setAñoFabricacion(2014);
		dron3.setAutonomiaMin(12.5);
		dron3.setActivo(false);
		dron3.setPesoKg(20.0);
		
		//4
		System.out.println(4);
		System.out.println(dronService.listarDrones());
		
		//5
		System.out.println(5);
		System.out.println(dronService.buscarPorId(dron1.getId()));
		
		//6
		Instrumento ins1 = new Instrumento();
		ins1.setTipo("camara R");
		ins1.setResolucion(12.0);
		ins1.setUnidadMedida("MP");
		ins1.setAlcanceMax(100.0);
		ins1.setConsumoEnergia(6.0);
		ins1.setHabilititado(true);
		instrumentoService.agregarInstrumento(dron1.getId(), ins1);
		Instrumento ins2 = new Instrumento();
		ins2.setTipo("lidar");
		ins2.setResolucion(0.05);
		ins2.setUnidadMedida("m");
		ins2.setAlcanceMax(200.0);
		ins2.setConsumoEnergia(10.0);
		ins2.setHabilititado(true);
		instrumentoService.agregarInstrumento(dron1.getId(), ins2);
		Instrumento ins3 = new Instrumento();
		ins3.setTipo("espectro");
		ins3.setResolucion(0.001);
		ins3.setUnidadMedida("nm");
		ins3.setAlcanceMax(50.0);
		ins3.setConsumoEnergia(3.5);
		ins3.setHabilititado(false);
		instrumentoService.agregarInstrumento(dron1.getId(), ins3);
		
		System.out.println(7);
		for (Drone dron : dronService.buscarPorMision("reconocimiento")) {
			System.out.println(dron);
		}
		
		System.out.println(8);
		for (Drone dron : dronService.buscarPorAnioFabricacion(2010, 2019)) {
			System.out.println(dron);
		}
			
		System.out.println(9);
		System.out.println(dronService.contarNoActivos());
		
		System.out.println(10);
		List<Drone> ins = dronService.obtenerConAutonomiaCritica(20d);
		System.out.println(ins.size());
		
		System.out.println(11);
		System.out.println(dronService.obtenerDroneMasReciente());
		
		System.out.println(12);
		for (Instrumento inss : instrumentoService.habilitadosBajoConsumo(5.0)) {
			System.out.println(inss);
		}
		System.out.println(13);
		//System.out.println(instrumentoService.habilitadosOrdenadosPorConsumo());
		
		System.out.println(14);
		for (Instrumento inss : instrumentoService.tipoCamaraConAlcance(10d)) {
			System.out.println(inss);
		}
		System.out.println(15);
		Boolean v = dronService.existePorModelo("Aero-900");
		if(v == false) {
			System.out.println("No existe el modelo");
		}else {
			System.out.println("Si existe el modelo");
		}	
	}
}

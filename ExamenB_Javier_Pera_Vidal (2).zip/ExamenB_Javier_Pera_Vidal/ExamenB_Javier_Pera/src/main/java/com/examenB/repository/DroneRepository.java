package com.examenB.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examenB.model.Drone;
@Repository
public interface DroneRepository extends JpaRepository<Drone,Long> {

	
	List<Drone> findByMision(String mision);
	
	List<Drone> findByAutonomiaMinLessThan(Double minAutonomia);
	
	List<Drone> findByMisionContainingIgnoreCase(String cadena);
	
	List<Drone> findByAñoFabricacionBetween(Integer start,Integer end);
	
	Long countByActivo(Boolean t);
	
}

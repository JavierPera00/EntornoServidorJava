package com.EjercicioRepaso.service;

import java.util.List;
import java.util.Optional;

import com.EjercicioRepaso.model.Muestrario;
import com.EjercicioRepaso.model.Receta;

public interface MuestrarioService {
	// Crear Receta
	Muestrario crearMuestrario(Muestrario r);

	// Borrar Receta por ID
	void eliminarMuestrario(Long id);

	// Buscar Receta por ID
	Muestrario buscarMuestrario(Long id);

	// Listar todas las recetas
	List<Muestrario> listarMuestrario();

	// Actualizar Receta
	Muestrario actualizarMuestrario(Muestrario r);
	
	// Nuevos Metodos
	void asignarRecetaMuestrario (Receta receta, Muestrario muestrario);
	
	void eliminarRecetaDeMuestrario(Receta receta, Muestrario muestrario);
	
	List<Receta> recetasMuestrarioEIngredientes(Long muestrarioId);

	Optional<Muestrario> findById(Long id);
}

package com.examenB.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table (name="drone")
public class Drone {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	@Column 
	private String modelo;
	@Column
	private String mision;
	@Column
	private Integer añoFabricacion;
	@Column
	private Double pesoKg;
	@Column
	private Boolean activo;
	@Column
	private Double autonomiaMin;
	@OneToMany(mappedBy="drones")
	private List<Instrumento> instrumentos = new ArrayList<>();
	
	public Drone() {
		super();
	}
	
	public Drone(String modelo, String mision, Integer añoFabricacion, Double pesoKg, Boolean activo,
			Double autonomiaMin) {
		super();
		this.modelo = modelo;
		this.mision = mision;
		this.añoFabricacion = añoFabricacion;
		this.pesoKg = pesoKg;
		this.activo = activo;
		this.autonomiaMin = autonomiaMin;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getMision() {
		return mision;
	}
	public void setMision(String mision) {
		this.mision = mision;
	}
	public Integer getAñoFabricacion() {
		return añoFabricacion;
	}
	public void setAñoFabricacion(Integer añoFabricacion) {
		this.añoFabricacion = añoFabricacion;
	}
	public Double getPesoKg() {
		return pesoKg;
	}
	public void setPesoKg(Double pesoKg) {
		this.pesoKg = pesoKg;
	}
	public Boolean getActivo() {
		return activo;
	}
	public void setActivo(Boolean activo) {
		this.activo = activo;
	}
	public Double getAutonomiaMin() {
		return autonomiaMin;
	}
	public void setAutonomiaMin(Double autonomiaMin) {
		this.autonomiaMin = autonomiaMin;
	}
	public List<Instrumento> getInstrumentos() {
		return instrumentos;
	}
	public void setInstrumentos(List<Instrumento> instrumentos) {
		this.instrumentos = instrumentos;
	}
	@Override
	public String toString() {
		return "Drone [id=" + id + ", modelo=" + modelo + ", mision=" + mision + ", añoFabricacion=" + añoFabricacion
				+ ", pesoKg=" + pesoKg + ", activo=" + activo + ", autonomiaMin=" + autonomiaMin + "]";
	}
}

package com.examenB.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.examenB.services.DroneService;
import com.examenB.services.InstrumentoService;

@Controller
public class Controllador {

	@Autowired
	DroneService dronService;
	@Autowired
	InstrumentoService instrumentoService;
	
	@GetMapping("/drones")
	public String mostrarIndex (Model model) {
		model.addAttribute("lista", dronService.listarDrones());
		return "drones";
	}
	
	@GetMapping("/instrumentos")
	public String mostrarIns () {
		return "instrumentosDrone";
	}
}
